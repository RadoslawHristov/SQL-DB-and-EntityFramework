﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-E6FDJ4T; TrustServerCertificate=True;Integrated Security=true;Database=Theatre";
    }
}
