﻿namespace Trucks.Data
{
    public class Configuration
    {
        public static string ConnectionString = 
            @"Server=DESKTOP-E6FDJ4T; TrustServerCertificate=True;Integrated Security=true;Database=Trucks";
        
    }
}